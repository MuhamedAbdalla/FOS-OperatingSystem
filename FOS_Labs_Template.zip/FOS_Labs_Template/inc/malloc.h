#ifndef FOS_INC_MALLOC_H
#define FOS_INC_MALLOC_H 1

void *malloc(uint32 size);
void freeHeap();

#endif
