// hello, world
#include <inc/lib.h>

void
_main(void)
{
	cprintf("HELLO WORLD , FOS IS SAYING HI :D:D:D\n");
}
